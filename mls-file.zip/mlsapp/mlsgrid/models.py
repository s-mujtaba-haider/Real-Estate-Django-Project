# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Apilogs(models.Model):
    created_at = models.DateTimeField(blank=True, null=True)
    level = models.CharField(max_length=10, blank=True, null=True)
    message = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'apilogs'


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=150)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    id = models.BigAutoField(primary_key=True)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.PositiveSmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    id = models.BigAutoField(primary_key=True)
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class Logrecords(models.Model):
    created_at = models.DateTimeField(blank=True, null=True)
    level = models.CharField(max_length=10, blank=True, null=True)
    message = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'logrecords'


class Lookup(models.Model):
    lookupkey = models.TextField(db_column='LookupKey', primary_key=True)  # Field name made lowercase.
    lookupname = models.TextField(db_column='LookupName', blank=True, null=True)  # Field name made lowercase.
    lookupvalue = models.TextField(db_column='LookupValue', blank=True, null=True)  # Field name made lowercase.
    mlgcanuse = models.TextField(db_column='MlgCanUse', blank=True, null=True)  # Field name made lowercase.
    mlgcanview = models.IntegerField(db_column='MlgCanView', blank=True, null=True)  # Field name made lowercase.
    modificationtimestamp = models.DateTimeField(db_column='ModificationTimestamp', blank=True, null=True)  # Field name made lowercase.
    originatingsystemname = models.TextField(db_column='OriginatingSystemName', blank=True, null=True)  # Field name made lowercase.
    standardlookupvalue = models.TextField(db_column='StandardLookupValue', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lookup'


class Media(models.Model):
    imageheight = models.BigIntegerField(db_column='ImageHeight', blank=True, null=True)  # Field name made lowercase.
    imagesizedescription = models.TextField(db_column='ImageSizeDescription', blank=True, null=True)  # Field name made lowercase.
    imagewidth = models.BigIntegerField(db_column='ImageWidth', blank=True, null=True)  # Field name made lowercase.
    longdescription = models.TextField(db_column='LongDescription', blank=True, null=True)  # Field name made lowercase.
    mediakey = models.TextField(db_column='MediaKey', primary_key=True)  # Field name made lowercase.
    mediamodificationtimestamp = models.DateTimeField(db_column='MediaModificationTimestamp', blank=True, null=True)  # Field name made lowercase.
    mediaobjectid = models.TextField(db_column='MediaObjectID', blank=True, null=True)  # Field name made lowercase.
    mediaurl = models.TextField(db_column='MediaURL', blank=True, null=True)  # Field name made lowercase.
    order = models.SmallIntegerField(db_column='Order', blank=True, null=True)  # Field name made lowercase.
    resourcerecordkey = models.TextField(db_column='ResourceRecordKey', blank=True, null=True)  # Field name made lowercase.
    listingid = models.TextField(db_column='ListingId', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'media'


class Member(models.Model):
    memberaddress1 = models.TextField(db_column='MemberAddress1', blank=True, null=True)  # Field name made lowercase.
    memberaddress2 = models.TextField(db_column='MemberAddress2', blank=True, null=True)  # Field name made lowercase.
    memberaor = models.TextField(db_column='MemberAOR', blank=True, null=True)  # Field name made lowercase.
    membercity = models.TextField(db_column='MemberCity', blank=True, null=True)  # Field name made lowercase.
    memberemail = models.TextField(db_column='MemberEmail', blank=True, null=True)  # Field name made lowercase.
    memberfirstname = models.TextField(db_column='MemberFirstName', blank=True, null=True)  # Field name made lowercase.
    memberfullname = models.TextField(db_column='MemberFullName', blank=True, null=True)  # Field name made lowercase.
    memberhomephone = models.CharField(db_column='MemberHomePhone', max_length=16, blank=True, null=True)  # Field name made lowercase.
    memberkey = models.TextField(db_column='MemberKey', blank=True, null=True)  # Field name made lowercase.
    memberlastname = models.TextField(db_column='MemberLastName', blank=True, null=True)  # Field name made lowercase.
    memberloginid = models.CharField(db_column='MemberLoginId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    membermiddlename = models.TextField(db_column='MemberMiddleName', blank=True, null=True)  # Field name made lowercase.
    membermlsid = models.CharField(db_column='MemberMlsId', primary_key=True, max_length=25)  # Field name made lowercase.
    membermobilephone = models.CharField(db_column='MemberMobilePhone', max_length=16, blank=True, null=True)  # Field name made lowercase.
    membernationalassociationid = models.CharField(db_column='MemberNationalAssociationId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    memberofficephone = models.CharField(db_column='MemberOfficePhone', max_length=16, blank=True, null=True)  # Field name made lowercase.
    memberpostalcode = models.CharField(db_column='MemberPostalCode', max_length=10, blank=True, null=True)  # Field name made lowercase.
    memberpreferredphone = models.CharField(db_column='MemberPreferredPhone', max_length=16, blank=True, null=True)  # Field name made lowercase.
    memberstateorprovince = models.CharField(db_column='MemberStateOrProvince', max_length=2, blank=True, null=True)  # Field name made lowercase.
    memberstatus = models.CharField(db_column='MemberStatus', max_length=25, blank=True, null=True)  # Field name made lowercase.
    membertype = models.TextField(db_column='MemberType', blank=True, null=True)  # Field name made lowercase.
    mlgcanuse = models.TextField(db_column='MlgCanUse', blank=True, null=True)  # Field name made lowercase.
    mlgcanview = models.IntegerField(db_column='MlgCanView', blank=True, null=True)  # Field name made lowercase.
    modificationtimestamp = models.DateTimeField(db_column='ModificationTimestamp', blank=True, null=True)  # Field name made lowercase.
    officekey = models.TextField(db_column='OfficeKey', blank=True, null=True)  # Field name made lowercase.
    officemlsid = models.CharField(db_column='OfficeMlsId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    originatingsystemname = models.TextField(db_column='OriginatingSystemName', blank=True, null=True)  # Field name made lowercase.
    membertest = models.TextField(db_column='MemberTest', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'member'


class Office(models.Model):
    idxofficeparticipationyn = models.IntegerField(db_column='IDXOfficeParticipationYN', blank=True, null=True)  # Field name made lowercase.
    mainofficemlsid = models.CharField(db_column='MainOfficeMlsId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    mlgcanuse = models.TextField(db_column='MlgCanUse', blank=True, null=True)  # Field name made lowercase.
    mlgcanview = models.IntegerField(db_column='MlgCanView', blank=True, null=True)  # Field name made lowercase.
    modificationtimestamp = models.DateTimeField(db_column='ModificationTimestamp', blank=True, null=True)  # Field name made lowercase.
    nst_firmname = models.TextField(db_column='NST_FirmName', blank=True, null=True)  # Field name made lowercase.
    officeaddress1 = models.TextField(db_column='OfficeAddress1', blank=True, null=True)  # Field name made lowercase.
    officeaddress2 = models.TextField(db_column='OfficeAddress2', blank=True, null=True)  # Field name made lowercase.
    officeaor = models.TextField(db_column='OfficeAOR', blank=True, null=True)  # Field name made lowercase.
    officecity = models.TextField(db_column='OfficeCity', blank=True, null=True)  # Field name made lowercase.
    officeemail = models.TextField(db_column='OfficeEmail', blank=True, null=True)  # Field name made lowercase.
    officefax = models.CharField(db_column='OfficeFax', max_length=16, blank=True, null=True)  # Field name made lowercase.
    officekey = models.TextField(db_column='OfficeKey', blank=True, null=True)  # Field name made lowercase.
    officemlsid = models.CharField(db_column='OfficeMlsId', primary_key=True, max_length=25)  # Field name made lowercase.
    officename = models.TextField(db_column='OfficeName', blank=True, null=True)  # Field name made lowercase.
    officenationalassociationid = models.CharField(db_column='OfficeNationalAssociationId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    officephone = models.CharField(db_column='OfficePhone', max_length=16, blank=True, null=True)  # Field name made lowercase.
    officepostalcode = models.CharField(db_column='OfficePostalCode', max_length=10, blank=True, null=True)  # Field name made lowercase.
    officestateorprovince = models.CharField(db_column='OfficeStateOrProvince', max_length=2, blank=True, null=True)  # Field name made lowercase.
    officestatus = models.CharField(db_column='OfficeStatus', max_length=25, blank=True, null=True)  # Field name made lowercase.
    originatingsystemname = models.TextField(db_column='OriginatingSystemName', blank=True, null=True)  # Field name made lowercase.
    originatingsystemofficekey = models.TextField(db_column='OriginatingSystemOfficeKey', blank=True, null=True)  # Field name made lowercase.
    photoschangetimestamp = models.DateTimeField(db_column='PhotosChangeTimestamp', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'office'


class Openhouse(models.Model):
    listingid = models.TextField(db_column='ListingId', blank=True, null=True)  # Field name made lowercase.
    listingkey = models.TextField(db_column='ListingKey', blank=True, null=True)  # Field name made lowercase.
    mlgcanuse = models.TextField(db_column='MlgCanUse', blank=True, null=True)  # Field name made lowercase.
    mlgcanview = models.IntegerField(db_column='MlgCanView', blank=True, null=True)  # Field name made lowercase.
    modificationtimestamp = models.DateTimeField(db_column='ModificationTimestamp', blank=True, null=True)  # Field name made lowercase.
    nst_virtualopenhousedetail = models.TextField(db_column='NST_VirtualOpenHouseDetail', blank=True, null=True)  # Field name made lowercase.
    nst_virtualopenhouseurl = models.TextField(db_column='NST_VirtualOpenHouseURL', blank=True, null=True)  # Field name made lowercase.
    openhousedate = models.DateField(db_column='OpenHouseDate', blank=True, null=True)  # Field name made lowercase.
    openhouseendtime = models.DateTimeField(db_column='OpenHouseEndTime', blank=True, null=True)  # Field name made lowercase.
    openhousekey = models.TextField(db_column='OpenHouseKey', primary_key=True)  # Field name made lowercase.
    openhouseremarks = models.TextField(db_column='OpenHouseRemarks', blank=True, null=True)  # Field name made lowercase.
    openhousestarttime = models.DateTimeField(db_column='OpenHouseStartTime', blank=True, null=True)  # Field name made lowercase.
    openhousestatus = models.CharField(db_column='OpenHouseStatus', max_length=25, blank=True, null=True)  # Field name made lowercase.
    openhousetype = models.CharField(db_column='OpenHouseType', max_length=25, blank=True, null=True)  # Field name made lowercase.
    originatingsystemname = models.TextField(db_column='OriginatingSystemName', blank=True, null=True)  # Field name made lowercase.
    refreshments = models.TextField(db_column='Refreshments', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'openhouse'


class Property(models.Model):
    abovegradefinishedarea = models.DecimalField(db_column='AboveGradeFinishedArea', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    accessibilityfeatures = models.TextField(db_column='AccessibilityFeatures', blank=True, null=True)  # Field name made lowercase.
    additionalparcelsdescription = models.TextField(db_column='AdditionalParcelsDescription', blank=True, null=True)  # Field name made lowercase.
    additionalparcelsyn = models.IntegerField(db_column='AdditionalParcelsYN', blank=True, null=True)  # Field name made lowercase.
    appliances = models.TextField(db_column='Appliances', blank=True, null=True)  # Field name made lowercase.
    architecturalstyle = models.TextField(db_column='ArchitecturalStyle', blank=True, null=True)  # Field name made lowercase.
    associationamenities = models.TextField(db_column='AssociationAmenities', blank=True, null=True)  # Field name made lowercase.
    associationfee = models.DecimalField(db_column='AssociationFee', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    associationfeefrequency = models.CharField(db_column='AssociationFeeFrequency', max_length=25, blank=True, null=True)  # Field name made lowercase.
    associationfeeincludes = models.TextField(db_column='AssociationFeeIncludes', blank=True, null=True)  # Field name made lowercase.
    associationname = models.TextField(db_column='AssociationName', blank=True, null=True)  # Field name made lowercase.
    associationphone = models.CharField(db_column='AssociationPhone', max_length=16, blank=True, null=True)  # Field name made lowercase.
    associationyn = models.IntegerField(db_column='AssociationYN', blank=True, null=True)  # Field name made lowercase.
    availabilitydate = models.DateField(db_column='AvailabilityDate', blank=True, null=True)  # Field name made lowercase.
    basement = models.TextField(db_column='Basement', blank=True, null=True)  # Field name made lowercase.
    basementyn = models.IntegerField(db_column='BasementYN', blank=True, null=True)  # Field name made lowercase.
    bathroomsfull = models.SmallIntegerField(db_column='BathroomsFull', blank=True, null=True)  # Field name made lowercase.
    bathroomshalf = models.SmallIntegerField(db_column='BathroomsHalf', blank=True, null=True)  # Field name made lowercase.
    bathroomsonequarter = models.SmallIntegerField(db_column='BathroomsOneQuarter', blank=True, null=True)  # Field name made lowercase.
    bathroomsthreequarter = models.SmallIntegerField(db_column='BathroomsThreeQuarter', blank=True, null=True)  # Field name made lowercase.
    bathroomstotalinteger = models.SmallIntegerField(db_column='BathroomsTotalInteger', blank=True, null=True)  # Field name made lowercase.
    bedroomstotal = models.SmallIntegerField(db_column='BedroomsTotal', blank=True, null=True)  # Field name made lowercase.
    belowgradefinishedarea = models.DecimalField(db_column='BelowGradeFinishedArea', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    buildername = models.TextField(db_column='BuilderName', blank=True, null=True)  # Field name made lowercase.
    buildingareasource = models.TextField(db_column='BuildingAreaSource', blank=True, null=True)  # Field name made lowercase.
    buildingareatotal = models.DecimalField(db_column='BuildingAreaTotal', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    buyeragencycompensation = models.CharField(db_column='BuyerAgencyCompensation', max_length=25, blank=True, null=True)  # Field name made lowercase.
    buyeragencycompensationtype = models.CharField(db_column='BuyerAgencyCompensationType', max_length=25, blank=True, null=True)  # Field name made lowercase.
    buyeragentkey = models.TextField(db_column='BuyerAgentKey', blank=True, null=True)  # Field name made lowercase.
    buyeragentmlsid = models.CharField(db_column='BuyerAgentMlsId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    buyerfinancing = models.TextField(db_column='BuyerFinancing', blank=True, null=True)  # Field name made lowercase.
    buyerofficekey = models.TextField(db_column='BuyerOfficeKey', blank=True, null=True)  # Field name made lowercase.
    buyerofficemlsid = models.CharField(db_column='BuyerOfficeMlsId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    buyerofficename = models.TextField(db_column='BuyerOfficeName', blank=True, null=True)  # Field name made lowercase.
    carportspaces = models.DecimalField(db_column='CarportSpaces', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    city = models.TextField(db_column='City', blank=True, null=True)  # Field name made lowercase.
    closedate = models.DateField(db_column='CloseDate', blank=True, null=True)  # Field name made lowercase.
    closeprice = models.DecimalField(db_column='ClosePrice', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    cobuyeragentkey = models.TextField(db_column='CoBuyerAgentKey', blank=True, null=True)  # Field name made lowercase.
    cobuyeragentmlsid = models.CharField(db_column='CoBuyerAgentMlsId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    colistagentfullname = models.TextField(db_column='CoListAgentFullName', blank=True, null=True)  # Field name made lowercase.
    colistagentkey = models.TextField(db_column='CoListAgentKey', blank=True, null=True)  # Field name made lowercase.
    colistagentmlsid = models.CharField(db_column='CoListAgentMlsId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    concessionsamount = models.BigIntegerField(db_column='ConcessionsAmount', blank=True, null=True)  # Field name made lowercase.
    constructionmaterials = models.TextField(db_column='ConstructionMaterials', blank=True, null=True)  # Field name made lowercase.
    contingency = models.TextField(db_column='Contingency', blank=True, null=True)  # Field name made lowercase.
    cooling = models.TextField(db_column='Cooling', blank=True, null=True)  # Field name made lowercase.
    countyorparish = models.TextField(db_column='CountyOrParish', blank=True, null=True)  # Field name made lowercase.
    crossstreet = models.TextField(db_column='CrossStreet', blank=True, null=True)  # Field name made lowercase.
    cultivatedarea = models.DecimalField(db_column='CultivatedArea', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    cumulativedaysonmarket = models.SmallIntegerField(db_column='CumulativeDaysOnMarket', blank=True, null=True)  # Field name made lowercase.
    currentuse = models.TextField(db_column='CurrentUse', blank=True, null=True)  # Field name made lowercase.
    daysonmarket = models.SmallIntegerField(db_column='DaysOnMarket', blank=True, null=True)  # Field name made lowercase.
    developmentstatus = models.TextField(db_column='DevelopmentStatus', blank=True, null=True)  # Field name made lowercase.
    directions = models.TextField(db_column='Directions', blank=True, null=True)  # Field name made lowercase.
    disclosures = models.TextField(db_column='Disclosures', blank=True, null=True)  # Field name made lowercase.
    documentsavailable = models.TextField(db_column='DocumentsAvailable', blank=True, null=True)  # Field name made lowercase.
    dualvariablecompensationyn = models.IntegerField(db_column='DualVariableCompensationYN', blank=True, null=True)  # Field name made lowercase.
    electric = models.TextField(db_column='Electric', blank=True, null=True)  # Field name made lowercase.
    electricexpense = models.DecimalField(db_column='ElectricExpense', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    elementaryschool = models.TextField(db_column='ElementarySchool', blank=True, null=True)  # Field name made lowercase.
    fencing = models.TextField(db_column='Fencing', blank=True, null=True)  # Field name made lowercase.
    fireplacefeatures = models.TextField(db_column='FireplaceFeatures', blank=True, null=True)  # Field name made lowercase.
    fireplacestotal = models.SmallIntegerField(db_column='FireplacesTotal', blank=True, null=True)  # Field name made lowercase.
    fireplaceyn = models.IntegerField(db_column='FireplaceYN', blank=True, null=True)  # Field name made lowercase.
    flooring = models.TextField(db_column='Flooring', blank=True, null=True)  # Field name made lowercase.
    foundationarea = models.DecimalField(db_column='FoundationArea', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    fuelexpense = models.DecimalField(db_column='FuelExpense', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    furnished = models.TextField(db_column='Furnished', blank=True, null=True)  # Field name made lowercase.
    garagespaces = models.DecimalField(db_column='GarageSpaces', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    grossincome = models.DecimalField(db_column='GrossIncome', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    heating = models.TextField(db_column='Heating', blank=True, null=True)  # Field name made lowercase.
    highschool = models.TextField(db_column='HighSchool', blank=True, null=True)  # Field name made lowercase.
    highschooldistrict = models.TextField(db_column='HighSchoolDistrict', blank=True, null=True)  # Field name made lowercase.
    homewarrantyyn = models.IntegerField(db_column='HomeWarrantyYN', blank=True, null=True)  # Field name made lowercase.
    inclusions = models.TextField(db_column='Inclusions', blank=True, null=True)  # Field name made lowercase.
    insuranceexpense = models.DecimalField(db_column='InsuranceExpense', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    internetaddressdisplayyn = models.IntegerField(db_column='InternetAddressDisplayYN', blank=True, null=True)  # Field name made lowercase.
    internetautomatedvaluationdisplayyn = models.IntegerField(db_column='InternetAutomatedValuationDisplayYN', blank=True, null=True)  # Field name made lowercase.
    internetconsumercommentyn = models.IntegerField(db_column='InternetConsumerCommentYN', blank=True, null=True)  # Field name made lowercase.
    internetentirelistingdisplayyn = models.IntegerField(db_column='InternetEntireListingDisplayYN', blank=True, null=True)  # Field name made lowercase.
    irrigationsource = models.TextField(db_column='IrrigationSource', blank=True, null=True)  # Field name made lowercase.
    landleaseamount = models.DecimalField(db_column='LandLeaseAmount', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    landleaseyn = models.IntegerField(db_column='LandLeaseYN', blank=True, null=True)  # Field name made lowercase.
    latitude = models.DecimalField(db_column='Latitude', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    laundryfeatures = models.TextField(db_column='LaundryFeatures', blank=True, null=True)  # Field name made lowercase.
    leaseterm = models.CharField(db_column='LeaseTerm', max_length=25, blank=True, null=True)  # Field name made lowercase.
    levels = models.TextField(db_column='Levels', blank=True, null=True)  # Field name made lowercase.
    listagentfullname = models.TextField(db_column='ListAgentFullName', blank=True, null=True)  # Field name made lowercase.
    listagentkey = models.TextField(db_column='ListAgentKey', blank=True, null=True)  # Field name made lowercase.
    listagentmlsid = models.CharField(db_column='ListAgentMlsId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    listagentofficephone = models.CharField(db_column='ListAgentOfficePhone', max_length=16, blank=True, null=True)  # Field name made lowercase.
    listingagreement = models.TextField(db_column='ListingAgreement', blank=True, null=True)  # Field name made lowercase.
    listingcontractdate = models.DateField(db_column='ListingContractDate', blank=True, null=True)  # Field name made lowercase.
    listingid = models.TextField(db_column='ListingId', primary_key=True)  # Field name made lowercase.
    listingkey = models.TextField(db_column='ListingKey', blank=True, null=True)  # Field name made lowercase.
    listingterms = models.TextField(db_column='ListingTerms', blank=True, null=True)  # Field name made lowercase.
    listofficekey = models.TextField(db_column='ListOfficeKey', blank=True, null=True)  # Field name made lowercase.
    listofficemlsid = models.CharField(db_column='ListOfficeMlsId', max_length=25, blank=True, null=True)  # Field name made lowercase.
    listofficename = models.TextField(db_column='ListOfficeName', blank=True, null=True)  # Field name made lowercase.
    listprice = models.DecimalField(db_column='ListPrice', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    livingarea = models.DecimalField(db_column='LivingArea', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    livingareaunits = models.CharField(db_column='LivingAreaUnits', max_length=25, blank=True, null=True)  # Field name made lowercase.
    lockboxtype = models.TextField(db_column='LockBoxType', blank=True, null=True)  # Field name made lowercase.
    longitude = models.DecimalField(db_column='Longitude', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    lotfeatures = models.TextField(db_column='LotFeatures', blank=True, null=True)  # Field name made lowercase.
    lotsizearea = models.DecimalField(db_column='LotSizeArea', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    lotsizedimensions = models.TextField(db_column='LotSizeDimensions', blank=True, null=True)  # Field name made lowercase.
    lotsizesource = models.TextField(db_column='LotSizeSource', blank=True, null=True)  # Field name made lowercase.
    lotsizesquarefeet = models.DecimalField(db_column='LotSizeSquareFeet', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    lotsizeunits = models.CharField(db_column='LotSizeUnits', max_length=25, blank=True, null=True)  # Field name made lowercase.
    mainlevelbedrooms = models.SmallIntegerField(db_column='MainLevelBedrooms', blank=True, null=True)  # Field name made lowercase.
    maintenanceexpense = models.DecimalField(db_column='MaintenanceExpense', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    managerexpense = models.DecimalField(db_column='ManagerExpense', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    mapcoordinate = models.CharField(db_column='MapCoordinate', max_length=25, blank=True, null=True)  # Field name made lowercase.
    mapcoordinatesource = models.CharField(db_column='MapCoordinateSource', max_length=25, blank=True, null=True)  # Field name made lowercase.
    middleorjuniorschool = models.TextField(db_column='MiddleOrJuniorSchool', blank=True, null=True)  # Field name made lowercase.
    mlgcanuse = models.TextField(db_column='MlgCanUse', blank=True, null=True)  # Field name made lowercase.
    mlgcanview = models.IntegerField(db_column='MlgCanView', blank=True, null=True)  # Field name made lowercase.
    modificationtimestamp = models.DateTimeField(db_column='ModificationTimestamp', blank=True, null=True)  # Field name made lowercase.
    netoperatingincome = models.DecimalField(db_column='NetOperatingIncome', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    newconstructionyn = models.IntegerField(db_column='NewConstructionYN', blank=True, null=True)  # Field name made lowercase.
    nst_abovegradesqfttotal = models.TextField(db_column='NST_AboveGradeSqFtTotal', blank=True, null=True)  # Field name made lowercase.
    nst_agentowner = models.TextField(db_column='NST_AgentOwner', blank=True, null=True)  # Field name made lowercase.
    nst_agentrelation = models.TextField(db_column='NST_AgentRelation', blank=True, null=True)  # Field name made lowercase.
    nst_ageofproperty = models.TextField(db_column='NST_AgeOfProperty', blank=True, null=True)  # Field name made lowercase.
    nst_amenitiesunit = models.TextField(db_column='NST_AmenitiesUnit', blank=True, null=True)  # Field name made lowercase.
    nst_applicationfee = models.TextField(db_column='NST_ApplicationFee', blank=True, null=True)  # Field name made lowercase.
    nst_approvedfinancing = models.TextField(db_column='NST_ApprovedFinancing', blank=True, null=True)  # Field name made lowercase.
    nst_assessmentpending = models.TextField(db_column='NST_AssessmentPending', blank=True, null=True)  # Field name made lowercase.
    nst_assumablemortgage = models.TextField(db_column='NST_AssumableMortgage', blank=True, null=True)  # Field name made lowercase.
    nst_attributioncontact = models.TextField(db_column='NST_AttributionContact', blank=True, null=True)  # Field name made lowercase.
    nst_attributionname = models.TextField(db_column='NST_AttributionName', blank=True, null=True)  # Field name made lowercase.
    nst_auctiondate = models.TextField(db_column='NST_AuctionDate', blank=True, null=True)  # Field name made lowercase.
    nst_auctioneerlicense = models.TextField(db_column='NST_AuctioneerLicense', blank=True, null=True)  # Field name made lowercase.
    nst_auctiontype = models.TextField(db_column='NST_AuctionType', blank=True, null=True)  # Field name made lowercase.
    nst_backgroundcheckreq = models.TextField(db_column='NST_BackgroundCheckReq', blank=True, null=True)  # Field name made lowercase.
    nst_bathdesc = models.TextField(db_column='NST_BathDesc', blank=True, null=True)  # Field name made lowercase.
    nst_belowgradesqfttotal = models.TextField(db_column='NST_BelowGradeSqFtTotal', blank=True, null=True)  # Field name made lowercase.
    nst_bonusamount = models.TextField(db_column='NST_BonusAmount', blank=True, null=True)  # Field name made lowercase.
    nst_bonusexpirationdate = models.TextField(db_column='NST_BonusExpirationDate', blank=True, null=True)  # Field name made lowercase.
    nst_bonusyn = models.TextField(db_column='NST_BonusYN', blank=True, null=True)  # Field name made lowercase.
    nst_brokeragelimitedservicetype = models.TextField(db_column='NST_BrokerageLimitedServiceType', blank=True, null=True)  # Field name made lowercase.
    nst_brokerredirectlink = models.TextField(db_column='NST_BrokerRedirectLink', blank=True, null=True)  # Field name made lowercase.
    nst_builderassociationid = models.TextField(db_column='NST_BuilderAssociationID', blank=True, null=True)  # Field name made lowercase.
    nst_builderlicense = models.TextField(db_column='NST_BuilderLicense', blank=True, null=True)  # Field name made lowercase.
    nst_builderrestrict = models.TextField(db_column='NST_BuilderRestrict', blank=True, null=True)  # Field name made lowercase.
    nst_buildingstories = models.TextField(db_column='NST_BuildingStories', blank=True, null=True)  # Field name made lowercase.
    nst_ceilingheight = models.TextField(db_column='NST_CeilingHeight', blank=True, null=True)  # Field name made lowercase.
    nst_cityassessedpropertytax = models.TextField(db_column='NST_CityAssessedPropertyTax', blank=True, null=True)  # Field name made lowercase.
    nst_cityrural = models.TextField(db_column='NST_CityRural', blank=True, null=True)  # Field name made lowercase.
    nst_comkitchenamendesc = models.TextField(db_column='NST_ComKitchenAmenDesc', blank=True, null=True)  # Field name made lowercase.
    nst_commissionpaidonconcessionsyn = models.TextField(db_column='NST_CommissionPaidOnConcessionsYN', blank=True, null=True)  # Field name made lowercase.
    nst_communityname = models.TextField(db_column='NST_CommunityName', blank=True, null=True)  # Field name made lowercase.
    nst_completiondate = models.TextField(db_column='NST_CompletionDate', blank=True, null=True)  # Field name made lowercase.
    nst_constructionmaterialsdesc = models.TextField(db_column='NST_ConstructionMaterialsDesc', blank=True, null=True)  # Field name made lowercase.
    nst_cornbase = models.TextField(db_column='NST_CornBase', blank=True, null=True)  # Field name made lowercase.
    nst_cornplcyield = models.TextField(db_column='NST_CornPLCYield', blank=True, null=True)  # Field name made lowercase.
    nst_cropindex = models.TextField(db_column='NST_CropIndex', blank=True, null=True)  # Field name made lowercase.
    nst_croptype = models.TextField(db_column='NST_CropType', blank=True, null=True)  # Field name made lowercase.
    nst_crpacres = models.TextField(db_column='NST_CRPAcres', blank=True, null=True)  # Field name made lowercase.
    nst_developmentamenitytype = models.TextField(db_column='NST_DevelopmentAmenityType', blank=True, null=True)  # Field name made lowercase.
    nst_devmaxprice = models.TextField(db_column='NST_DevMaxPrice', blank=True, null=True)  # Field name made lowercase.
    nst_devminprice = models.TextField(db_column='NST_DevMinPrice', blank=True, null=True)  # Field name made lowercase.
    nst_diningroomdescription = models.TextField(db_column='NST_DiningRoomDescription', blank=True, null=True)  # Field name made lowercase.
    nst_doortype = models.TextField(db_column='NST_DoorType', blank=True, null=True)  # Field name made lowercase.
    nst_dpresource = models.TextField(db_column='NST_DPResource', blank=True, null=True)  # Field name made lowercase.
    nst_driveindoor = models.TextField(db_column='NST_DriveInDoor', blank=True, null=True)  # Field name made lowercase.
    nst_efficiency = models.TextField(db_column='NST_Efficiency', blank=True, null=True)  # Field name made lowercase.
    nst_electricbudgetamount = models.TextField(db_column='NST_ElectricBudgetAmount', blank=True, null=True)  # Field name made lowercase.
    nst_expectedmarketdate = models.TextField(db_column='NST_ExpectedMarketDate', blank=True, null=True)  # Field name made lowercase.
    nst_expenses = models.TextField(db_column='NST_Expenses', blank=True, null=True)  # Field name made lowercase.
    nst_farmtype = models.TextField(db_column='NST_FarmType', blank=True, null=True)  # Field name made lowercase.
    nst_firenumber = models.TextField(db_column='NST_FireNumber', blank=True, null=True)  # Field name made lowercase.
    nst_firstfloorarea = models.TextField(db_column='NST_FirstFloorArea', blank=True, null=True)  # Field name made lowercase.
    nst_foreclosurestatus = models.TextField(db_column='NST_ForeclosureStatus', blank=True, null=True)  # Field name made lowercase.
    nst_forrentmlnumber = models.TextField(db_column='NST_ForRentMLNumber', blank=True, null=True)  # Field name made lowercase.
    nst_forsalemlnumber = models.TextField(db_column='NST_ForSaleMLNumber', blank=True, null=True)  # Field name made lowercase.
    nst_foundationdimensions = models.TextField(db_column='NST_FoundationDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_fractionalownershipyn = models.TextField(db_column='NST_FractionalOwnershipYN', blank=True, null=True)  # Field name made lowercase.
    nst_fuel = models.TextField(db_column='NST_Fuel', blank=True, null=True)  # Field name made lowercase.
    nst_garagedimensions = models.TextField(db_column='NST_GarageDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_garagedoorheight = models.TextField(db_column='NST_GarageDoorHeight', blank=True, null=True)  # Field name made lowercase.
    nst_garagedoorwidth = models.TextField(db_column='NST_GarageDoorWidth', blank=True, null=True)  # Field name made lowercase.
    nst_garagesquarefeet = models.TextField(db_column='NST_GarageSquareFeet', blank=True, null=True)  # Field name made lowercase.
    nst_garagestallnum = models.TextField(db_column='NST_GarageStallNum', blank=True, null=True)  # Field name made lowercase.
    nst_gasbudgetamount = models.TextField(db_column='NST_GasBudgetAmount', blank=True, null=True)  # Field name made lowercase.
    nst_greencertifiedstatus = models.TextField(db_column='NST_GreenCertifiedStatus', blank=True, null=True)  # Field name made lowercase.
    nst_improvements = models.TextField(db_column='NST_Improvements', blank=True, null=True)  # Field name made lowercase.
    nst_includeshouse = models.TextField(db_column='NST_IncludesHouse', blank=True, null=True)  # Field name made lowercase.
    nst_incomemiscann = models.TextField(db_column='NST_IncomeMiscAnn', blank=True, null=True)  # Field name made lowercase.
    nst_incomemiscmon = models.TextField(db_column='NST_IncomeMiscMon', blank=True, null=True)  # Field name made lowercase.
    nst_insurancefee = models.TextField(db_column='NST_InsuranceFee', blank=True, null=True)  # Field name made lowercase.
    nst_insurancefeefrequency = models.TextField(db_column='NST_InsuranceFeeFrequency', blank=True, null=True)  # Field name made lowercase.
    nst_interiortrim = models.TextField(db_column='NST_InteriorTrim', blank=True, null=True)  # Field name made lowercase.
    nst_internetoptions = models.TextField(db_column='NST_InternetOptions', blank=True, null=True)  # Field name made lowercase.
    nst_irrigationsystem = models.TextField(db_column='NST_IrrigationSystem', blank=True, null=True)  # Field name made lowercase.
    nst_isbuyerspremium = models.TextField(db_column='NST_IsBuyersPremium', blank=True, null=True)  # Field name made lowercase.
    nst_isnewdevelopment = models.TextField(db_column='NST_IsNewDevelopment', blank=True, null=True)  # Field name made lowercase.
    nst_lakeacres = models.TextField(db_column='NST_LakeAcres', blank=True, null=True)  # Field name made lowercase.
    nst_lakebottom = models.TextField(db_column='NST_LakeBottom', blank=True, null=True)  # Field name made lowercase.
    nst_lakechain = models.TextField(db_column='NST_LakeChain', blank=True, null=True)  # Field name made lowercase.
    nst_lakechainacreage = models.TextField(db_column='NST_LakeChainAcreage', blank=True, null=True)  # Field name made lowercase.
    nst_lakechainname = models.TextField(db_column='NST_LakeChainName', blank=True, null=True)  # Field name made lowercase.
    nst_lakeclass = models.TextField(db_column='NST_LakeClass', blank=True, null=True)  # Field name made lowercase.
    nst_lakedepth = models.TextField(db_column='NST_LakeDepth', blank=True, null=True)  # Field name made lowercase.
    nst_landfeatures = models.TextField(db_column='NST_LandFeatures', blank=True, null=True)  # Field name made lowercase.
    nst_lastupdatedate = models.TextField(db_column='NST_LastUpdateDate', blank=True, null=True)  # Field name made lowercase.
    nst_leaseamounttype = models.TextField(db_column='NST_LeaseAmountType', blank=True, null=True)  # Field name made lowercase.
    nst_leasedacres = models.TextField(db_column='NST_LeasedAcres', blank=True, null=True)  # Field name made lowercase.
    nst_leasedacresexp = models.TextField(db_column='NST_LeasedAcresExp', blank=True, null=True)  # Field name made lowercase.
    nst_leaseexpirationdate = models.TextField(db_column='NST_LeaseExpirationDate', blank=True, null=True)  # Field name made lowercase.
    nst_leaseprice = models.TextField(db_column='NST_LeasePrice', blank=True, null=True)  # Field name made lowercase.
    nst_leasetype = models.TextField(db_column='NST_LeaseType', blank=True, null=True)  # Field name made lowercase.
    nst_lenderowned = models.TextField(db_column='NST_LenderOwned', blank=True, null=True)  # Field name made lowercase.
    nst_licenseeassistingsellertype = models.TextField(db_column='NST_LicenseeAssistingSellerType', blank=True, null=True)  # Field name made lowercase.
    nst_listpricehigh = models.TextField(db_column='NST_ListPriceHigh', blank=True, null=True)  # Field name made lowercase.
    nst_livestockconfinementdesc = models.TextField(db_column='NST_LivestockConfinementDesc', blank=True, null=True)  # Field name made lowercase.
    nst_lockboxsource = models.TextField(db_column='NST_LockBoxSource', blank=True, null=True)  # Field name made lowercase.
    nst_lotnumber = models.TextField(db_column='NST_LotNumber', blank=True, null=True)  # Field name made lowercase.
    nst_lotprice = models.TextField(db_column='NST_LotPrice', blank=True, null=True)  # Field name made lowercase.
    nst_lotsizemin = models.TextField(db_column='NST_LotSizeMin', blank=True, null=True)  # Field name made lowercase.
    nst_lowerlevelbathroomfull = models.TextField(db_column='NST_LowerLevelBathroomFull', blank=True, null=True)  # Field name made lowercase.
    nst_lowerlevelbathroomhalf = models.TextField(db_column='NST_LowerLevelBathroomHalf', blank=True, null=True)  # Field name made lowercase.
    nst_lowerlevelbedroom = models.TextField(db_column='NST_LowerLevelBedroom', blank=True, null=True)  # Field name made lowercase.
    nst_lowlandacres = models.TextField(db_column='NST_LowlandAcres', blank=True, null=True)  # Field name made lowercase.
    nst_machineryincluded = models.TextField(db_column='NST_MachineryIncluded', blank=True, null=True)  # Field name made lowercase.
    nst_mainandupperbathroom = models.TextField(db_column='NST_MainAndUpperBathroom', blank=True, null=True)  # Field name made lowercase.
    nst_mainandupperbedroom = models.TextField(db_column='NST_MainAndUpperBedroom', blank=True, null=True)  # Field name made lowercase.
    nst_mainlevelbathroomfull = models.TextField(db_column='NST_MainLevelBathroomFull', blank=True, null=True)  # Field name made lowercase.
    nst_mainlevelbathroomhalf = models.TextField(db_column='NST_MainLevelBathroomHalf', blank=True, null=True)  # Field name made lowercase.
    nst_mainlevelfinishedarea = models.TextField(db_column='NST_MainLevelFinishedArea', blank=True, null=True)  # Field name made lowercase.
    nst_manufacturedhome = models.TextField(db_column='NST_ManufacturedHome', blank=True, null=True)  # Field name made lowercase.
    nst_modelhours = models.TextField(db_column='NST_ModelHours', blank=True, null=True)  # Field name made lowercase.
    nst_modellocation = models.TextField(db_column='NST_ModelLocation', blank=True, null=True)  # Field name made lowercase.
    nst_modelphone = models.TextField(db_column='NST_ModelPhone', blank=True, null=True)  # Field name made lowercase.
    nst_mortgagebalance = models.TextField(db_column='NST_MortgageBalance', blank=True, null=True)  # Field name made lowercase.
    nst_mortgagetype = models.TextField(db_column='NST_MortgageType', blank=True, null=True)  # Field name made lowercase.
    nst_neighborhoodnumber = models.TextField(db_column='NST_NeighborhoodNumber', blank=True, null=True)  # Field name made lowercase.
    nst_occupancydate = models.TextField(db_column='NST_OccupancyDate', blank=True, null=True)  # Field name made lowercase.
    nst_officearea = models.TextField(db_column='NST_OfficeArea', blank=True, null=True)  # Field name made lowercase.
    nst_officeboard = models.TextField(db_column='NST_OfficeBoard', blank=True, null=True)  # Field name made lowercase.
    nst_officecount = models.TextField(db_column='NST_OfficeCount', blank=True, null=True)  # Field name made lowercase.
    nst_otherdepositsfees = models.TextField(db_column='NST_OtherDepositsFees', blank=True, null=True)  # Field name made lowercase.
    nst_overheaddoorclearance = models.TextField(db_column='NST_OverheadDoorClearance', blank=True, null=True)  # Field name made lowercase.
    nst_owneroccupied = models.TextField(db_column='NST_OwnerOccupied', blank=True, null=True)  # Field name made lowercase.
    nst_parkingopen = models.TextField(db_column='NST_ParkingOpen', blank=True, null=True)  # Field name made lowercase.
    nst_patioporchtype = models.TextField(db_column='NST_PatioPorchType', blank=True, null=True)  # Field name made lowercase.
    nst_percentownership = models.TextField(db_column='NST_PercentOwnership', blank=True, null=True)  # Field name made lowercase.
    nst_petdeposit = models.TextField(db_column='NST_PetDeposit', blank=True, null=True)  # Field name made lowercase.
    nst_potentialshortsale = models.TextField(db_column='NST_PotentialShortSale', blank=True, null=True)  # Field name made lowercase.
    nst_powercompanyname = models.TextField(db_column='NST_PowerCompanyName', blank=True, null=True)  # Field name made lowercase.
    nst_prepaidrent = models.TextField(db_column='NST_PrePaidRent', blank=True, null=True)  # Field name made lowercase.
    nst_presentuse = models.TextField(db_column='NST_PresentUse', blank=True, null=True)  # Field name made lowercase.
    nst_programacrestotal = models.TextField(db_column='NST_ProgramAcresTotal', blank=True, null=True)  # Field name made lowercase.
    nst_programexpirationdate = models.TextField(db_column='NST_ProgramExpirationDate', blank=True, null=True)  # Field name made lowercase.
    nst_propertysubtypedesc = models.TextField(db_column='NST_PropertySubTypeDesc', blank=True, null=True)  # Field name made lowercase.
    nst_proposedtitledate = models.TextField(db_column='NST_ProposedTitleDate', blank=True, null=True)  # Field name made lowercase.
    nst_rangenum = models.TextField(db_column='NST_RangeNum', blank=True, null=True)  # Field name made lowercase.
    nst_refrigeratornum = models.TextField(db_column='NST_RefrigeratorNum', blank=True, null=True)  # Field name made lowercase.
    nst_remarksfinancial = models.TextField(db_column='NST_RemarksFinancial', blank=True, null=True)  # Field name made lowercase.
    nst_rentallicensetype = models.TextField(db_column='NST_RentalLicenseType', blank=True, null=True)  # Field name made lowercase.
    nst_rentallicenseyn = models.TextField(db_column='NST_RentalLicenseYN', blank=True, null=True)  # Field name made lowercase.
    nst_rentmonthlyoriginal = models.TextField(db_column='NST_RentMonthlyOriginal', blank=True, null=True)  # Field name made lowercase.
    nst_reservedbuyer = models.TextField(db_column='NST_ReservedBuyer', blank=True, null=True)  # Field name made lowercase.
    nst_restrictions = models.TextField(db_column='NST_Restrictions', blank=True, null=True)  # Field name made lowercase.
    nst_rimacres = models.TextField(db_column='NST_RIMAcres', blank=True, null=True)  # Field name made lowercase.
    nst_roadbetweenwaterfrontandhomeyn = models.TextField(db_column='NST_RoadBetweenWaterfrontAndHomeYN', blank=True, null=True)  # Field name made lowercase.
    nst_roadfrontagelength = models.TextField(db_column='NST_RoadFrontageLength', blank=True, null=True)  # Field name made lowercase.
    nst_roadfrontagelengthunit = models.TextField(db_column='NST_RoadFrontageLengthUnit', blank=True, null=True)  # Field name made lowercase.
    nst_saleoptions = models.TextField(db_column='NST_SaleOptions', blank=True, null=True)  # Field name made lowercase.
    nst_schooldistrictnumber = models.TextField(db_column='NST_SchoolDistrictNumber', blank=True, null=True)  # Field name made lowercase.
    nst_schooldistrictphone = models.TextField(db_column='NST_SchoolDistrictPhone', blank=True, null=True)  # Field name made lowercase.
    nst_secondfloorarea = models.TextField(db_column='NST_SecondFloorArea', blank=True, null=True)  # Field name made lowercase.
    nst_secondunit = models.TextField(db_column='NST_SecondUnit', blank=True, null=True)  # Field name made lowercase.
    nst_securitydeposit = models.TextField(db_column='NST_SecurityDeposit', blank=True, null=True)  # Field name made lowercase.
    nst_sharedrooms = models.TextField(db_column='NST_SharedRooms', blank=True, null=True)  # Field name made lowercase.
    nst_smokingpermitted = models.TextField(db_column='NST_SmokingPermitted', blank=True, null=True)  # Field name made lowercase.
    nst_soiltype = models.TextField(db_column='NST_SoilType', blank=True, null=True)  # Field name made lowercase.
    nst_solarrights = models.TextField(db_column='NST_SolarRights', blank=True, null=True)  # Field name made lowercase.
    nst_solarrightsannualpayment = models.TextField(db_column='NST_SolarRightsAnnualPayment', blank=True, null=True)  # Field name made lowercase.
    nst_soybeanbase = models.TextField(db_column='NST_SoybeanBase', blank=True, null=True)  # Field name made lowercase.
    nst_soybeanplcyield = models.TextField(db_column='NST_SoybeanPLCYield', blank=True, null=True)  # Field name made lowercase.
    nst_specialsearch = models.TextField(db_column='NST_SpecialSearch', blank=True, null=True)  # Field name made lowercase.
    nst_sqfttotal = models.TextField(db_column='NST_SqFtTotal', blank=True, null=True)  # Field name made lowercase.
    nst_statuskickouthours = models.TextField(db_column='NST_StatusKickoutHours', blank=True, null=True)  # Field name made lowercase.
    nst_subleaseexpirationdate = models.TextField(db_column='NST_SubLeaseExpirationDate', blank=True, null=True)  # Field name made lowercase.
    nst_subleaseyn = models.TextField(db_column='NST_SubLeaseYN', blank=True, null=True)  # Field name made lowercase.
    nst_taxableacres = models.TextField(db_column='NST_TaxableAcres', blank=True, null=True)  # Field name made lowercase.
    nst_taxexemptiontype = models.TextField(db_column='NST_TaxExemptionType', blank=True, null=True)  # Field name made lowercase.
    nst_taxexemptyn = models.TextField(db_column='NST_TaxExemptYN', blank=True, null=True)  # Field name made lowercase.
    nst_taxwithassessments = models.TextField(db_column='NST_TaxWithAssessments', blank=True, null=True)  # Field name made lowercase.
    nst_thcharacteristics = models.TextField(db_column='NST_THCharacteristics', blank=True, null=True)  # Field name made lowercase.
    nst_tiledacres = models.TextField(db_column='NST_TiledAcres', blank=True, null=True)  # Field name made lowercase.
    nst_tiledacrespartial = models.TextField(db_column='NST_TiledAcresPartial', blank=True, null=True)  # Field name made lowercase.
    nst_tilespacing = models.TextField(db_column='NST_TileSpacing', blank=True, null=True)  # Field name made lowercase.
    nst_totalunitsavailable = models.TextField(db_column='NST_TotalUnitsAvailable', blank=True, null=True)  # Field name made lowercase.
    nst_totalunitsincomplex = models.TextField(db_column='NST_TotalUnitsInComplex', blank=True, null=True)  # Field name made lowercase.
    nst_totalunitssold = models.TextField(db_column='NST_TotalUnitsSold', blank=True, null=True)  # Field name made lowercase.
    nst_upperlevelbathroomfull = models.TextField(db_column='NST_UpperLevelBathroomFull', blank=True, null=True)  # Field name made lowercase.
    nst_upperlevelbathroomhalf = models.TextField(db_column='NST_UpperLevelBathroomHalf', blank=True, null=True)  # Field name made lowercase.
    nst_upperlevelbedroom = models.TextField(db_column='NST_UpperLevelBedroom', blank=True, null=True)  # Field name made lowercase.
    nst_virtualtoururlunbranded2 = models.TextField(db_column='NST_VirtualTourURLUnbranded2', blank=True, null=True)  # Field name made lowercase.
    nst_wasteacres = models.TextField(db_column='NST_WasteAcres', blank=True, null=True)  # Field name made lowercase.
    nst_waterfrontelevation = models.TextField(db_column='NST_WaterfrontElevation', blank=True, null=True)  # Field name made lowercase.
    nst_waterfrontfeet = models.TextField(db_column='NST_WaterfrontFeet', blank=True, null=True)  # Field name made lowercase.
    nst_waterfrontnum = models.TextField(db_column='NST_WaterfrontNum', blank=True, null=True)  # Field name made lowercase.
    nst_waterfrontslope = models.TextField(db_column='NST_WaterfrontSlope', blank=True, null=True)  # Field name made lowercase.
    nst_wetlandstatus = models.TextField(db_column='NST_WetlandStatus', blank=True, null=True)  # Field name made lowercase.
    nst_windrights = models.TextField(db_column='NST_WindRights', blank=True, null=True)  # Field name made lowercase.
    nst_windrightsannualpayment = models.TextField(db_column='NST_WindRightsAnnualPayment', blank=True, null=True)  # Field name made lowercase.
    nst_wrpacres = models.TextField(db_column='NST_WRPAcres', blank=True, null=True)  # Field name made lowercase.
    numberofbuildings = models.SmallIntegerField(db_column='NumberOfBuildings', blank=True, null=True)  # Field name made lowercase.
    numberofunitstotal = models.SmallIntegerField(db_column='NumberOfUnitsTotal', blank=True, null=True)  # Field name made lowercase.
    occupantname = models.TextField(db_column='OccupantName', blank=True, null=True)  # Field name made lowercase.
    occupanttype = models.TextField(db_column='OccupantType', blank=True, null=True)  # Field name made lowercase.
    offmarketdate = models.DateField(db_column='OffMarketDate', blank=True, null=True)  # Field name made lowercase.
    operatingexpense = models.DecimalField(db_column='OperatingExpense', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    originalentrytimestamp = models.DateTimeField(db_column='OriginalEntryTimestamp', blank=True, null=True)  # Field name made lowercase.
    originallistprice = models.DecimalField(db_column='OriginalListPrice', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    originatingsystemmodificationtimestamp = models.DateTimeField(db_column='OriginatingSystemModificationTimestamp', blank=True, null=True)  # Field name made lowercase.
    originatingsystemname = models.TextField(db_column='OriginatingSystemName', blank=True, null=True)  # Field name made lowercase.
    otherexpense = models.DecimalField(db_column='OtherExpense', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    otherstructures = models.TextField(db_column='OtherStructures', blank=True, null=True)  # Field name made lowercase.
    ownername = models.TextField(db_column='OwnerName', blank=True, null=True)  # Field name made lowercase.
    ownerpays = models.TextField(db_column='OwnerPays', blank=True, null=True)  # Field name made lowercase.
    ownerphone = models.CharField(db_column='OwnerPhone', max_length=16, blank=True, null=True)  # Field name made lowercase.
    ownershiptype = models.TextField(db_column='OwnershipType', blank=True, null=True)  # Field name made lowercase.
    parcelnumber = models.TextField(db_column='ParcelNumber', blank=True, null=True)  # Field name made lowercase.
    parkingfeatures = models.TextField(db_column='ParkingFeatures', blank=True, null=True)  # Field name made lowercase.
    pasturearea = models.DecimalField(db_column='PastureArea', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    photoschangetimestamp = models.DateTimeField(db_column='PhotosChangeTimestamp', blank=True, null=True)  # Field name made lowercase.
    photoscount = models.SmallIntegerField(db_column='PhotosCount', blank=True, null=True)  # Field name made lowercase.
    poolfeatures = models.TextField(db_column='PoolFeatures', blank=True, null=True)  # Field name made lowercase.
    possession = models.TextField(db_column='Possession', blank=True, null=True)  # Field name made lowercase.
    possibleuse = models.TextField(db_column='PossibleUse', blank=True, null=True)  # Field name made lowercase.
    postalcity = models.TextField(db_column='PostalCity', blank=True, null=True)  # Field name made lowercase.
    postalcode = models.CharField(db_column='PostalCode', max_length=10, blank=True, null=True)  # Field name made lowercase.
    privateremarks = models.TextField(db_column='PrivateRemarks', blank=True, null=True)  # Field name made lowercase.
    propertyattachedyn = models.IntegerField(db_column='PropertyAttachedYN', blank=True, null=True)  # Field name made lowercase.
    propertysubtype = models.TextField(db_column='PropertySubType', blank=True, null=True)  # Field name made lowercase.
    propertytype = models.TextField(db_column='PropertyType', blank=True, null=True)  # Field name made lowercase.
    publicremarks = models.TextField(db_column='PublicRemarks', blank=True, null=True)  # Field name made lowercase.
    publicsurveyrange = models.CharField(db_column='PublicSurveyRange', max_length=20, blank=True, null=True)  # Field name made lowercase.
    publicsurveysection = models.CharField(db_column='PublicSurveySection', max_length=20, blank=True, null=True)  # Field name made lowercase.
    publicsurveytownship = models.CharField(db_column='PublicSurveyTownship', max_length=20, blank=True, null=True)  # Field name made lowercase.
    purchasecontractdate = models.DateField(db_column='PurchaseContractDate', blank=True, null=True)  # Field name made lowercase.
    roadfrontagetype = models.TextField(db_column='RoadFrontageType', blank=True, null=True)  # Field name made lowercase.
    roadresponsibility = models.TextField(db_column='RoadResponsibility', blank=True, null=True)  # Field name made lowercase.
    roof = models.TextField(db_column='Roof', blank=True, null=True)  # Field name made lowercase.
    roomstotal = models.SmallIntegerField(db_column='RoomsTotal', blank=True, null=True)  # Field name made lowercase.
    roomtype = models.TextField(db_column='RoomType', blank=True, null=True)  # Field name made lowercase.
    sewer = models.TextField(db_column='Sewer', blank=True, null=True)  # Field name made lowercase.
    showingcontactphone = models.CharField(db_column='ShowingContactPhone', max_length=16, blank=True, null=True)  # Field name made lowercase.
    showingrequirements = models.TextField(db_column='ShowingRequirements', blank=True, null=True)  # Field name made lowercase.
    sourcesystemname = models.TextField(db_column='SourceSystemName', blank=True, null=True)  # Field name made lowercase.
    speciallistingconditions = models.TextField(db_column='SpecialListingConditions', blank=True, null=True)  # Field name made lowercase.
    standardstatus = models.CharField(db_column='StandardStatus', max_length=25, blank=True, null=True)  # Field name made lowercase.
    stateorprovince = models.CharField(db_column='StateOrProvince', max_length=2, blank=True, null=True)  # Field name made lowercase.
    streetdirprefix = models.CharField(db_column='StreetDirPrefix', max_length=15, blank=True, null=True)  # Field name made lowercase.
    streetdirsuffix = models.CharField(db_column='StreetDirSuffix', max_length=15, blank=True, null=True)  # Field name made lowercase.
    streetname = models.TextField(db_column='StreetName', blank=True, null=True)  # Field name made lowercase.
    streetnumber = models.CharField(db_column='StreetNumber', max_length=25, blank=True, null=True)  # Field name made lowercase.
    streetnumbernumeric = models.IntegerField(db_column='StreetNumberNumeric', blank=True, null=True)  # Field name made lowercase.
    streetsuffix = models.CharField(db_column='StreetSuffix', max_length=25, blank=True, null=True)  # Field name made lowercase.
    subagencycompensation = models.CharField(db_column='SubAgencyCompensation', max_length=25, blank=True, null=True)  # Field name made lowercase.
    subagencycompensationtype = models.CharField(db_column='SubAgencyCompensationType', max_length=25, blank=True, null=True)  # Field name made lowercase.
    subdivisionname = models.TextField(db_column='SubdivisionName', blank=True, null=True)  # Field name made lowercase.
    taxannualamount = models.DecimalField(db_column='TaxAnnualAmount', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    taxlegaldescription = models.TextField(db_column='TaxLegalDescription', blank=True, null=True)  # Field name made lowercase.
    taxotherannualassessmentamount = models.DecimalField(db_column='TaxOtherAnnualAssessmentAmount', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    taxyear = models.SmallIntegerField(db_column='TaxYear', blank=True, null=True)  # Field name made lowercase.
    tenantpays = models.TextField(db_column='TenantPays', blank=True, null=True)  # Field name made lowercase.
    topography = models.TextField(db_column='Topography', blank=True, null=True)  # Field name made lowercase.
    township = models.TextField(db_column='Township', blank=True, null=True)  # Field name made lowercase.
    transactionbrokercompensation = models.CharField(db_column='TransactionBrokerCompensation', max_length=25, blank=True, null=True)  # Field name made lowercase.
    transactionbrokercompensationtype = models.CharField(db_column='TransactionBrokerCompensationType', max_length=25, blank=True, null=True)  # Field name made lowercase.
    trashexpense = models.DecimalField(db_column='TrashExpense', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    unitnumber = models.CharField(db_column='UnitNumber', max_length=25, blank=True, null=True)  # Field name made lowercase.
    utilities = models.TextField(db_column='Utilities', blank=True, null=True)  # Field name made lowercase.
    view = models.TextField(db_column='View', blank=True, null=True)  # Field name made lowercase.
    virtualtoururlunbranded = models.TextField(db_column='VirtualTourURLUnbranded', blank=True, null=True)  # Field name made lowercase.
    waterbodyname = models.TextField(db_column='WaterBodyName', blank=True, null=True)  # Field name made lowercase.
    waterfrontfeatures = models.TextField(db_column='WaterfrontFeatures', blank=True, null=True)  # Field name made lowercase.
    waterfrontyn = models.IntegerField(db_column='WaterfrontYN', blank=True, null=True)  # Field name made lowercase.
    watersewerexpense = models.DecimalField(db_column='WaterSewerExpense', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    watersource = models.TextField(db_column='WaterSource', blank=True, null=True)  # Field name made lowercase.
    windowfeatures = models.TextField(db_column='WindowFeatures', blank=True, null=True)  # Field name made lowercase.
    woodedarea = models.DecimalField(db_column='WoodedArea', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    yearbuilt = models.SmallIntegerField(db_column='YearBuilt', blank=True, null=True)  # Field name made lowercase.
    zoningdescription = models.TextField(db_column='ZoningDescription', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'property'


class Propertyrooms(models.Model):
    nst_roomsortorder = models.TextField(db_column='NST_RoomSortOrder', blank=True, null=True)  # Field name made lowercase.
    roomdimensions = models.TextField(db_column='RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    roomkey = models.TextField(db_column='RoomKey', primary_key=True)  # Field name made lowercase.
    roomlevel = models.CharField(db_column='RoomLevel', max_length=25, blank=True, null=True)  # Field name made lowercase.
    roomtype = models.TextField(db_column='RoomType', blank=True, null=True)  # Field name made lowercase.
    listingid = models.TextField(db_column='ListingId', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'propertyrooms'


class Propertyunittypes(models.Model):
    nst_bathdescription = models.TextField(db_column='NST_BathDescription', blank=True, null=True)  # Field name made lowercase.
    nst_bedroom1roomdimensions = models.TextField(db_column='NST_Bedroom1RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_bedroom1roomlevel = models.TextField(db_column='NST_Bedroom1RoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_bedroom2roomdimensions = models.TextField(db_column='NST_Bedroom2RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_bedroom2roomlevel = models.TextField(db_column='NST_Bedroom2RoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_bedroom3roomdimensions = models.TextField(db_column='NST_Bedroom3RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_bedroom3roomlevel = models.TextField(db_column='NST_Bedroom3RoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_bedroom4roomdimensions = models.TextField(db_column='NST_Bedroom4RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_bedroom4roomlevel = models.TextField(db_column='NST_Bedroom4RoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_diningroomroomdescription = models.TextField(db_column='NST_DiningRoomRoomDescription', blank=True, null=True)  # Field name made lowercase.
    nst_diningroomroomdimensions = models.TextField(db_column='NST_DiningRoomRoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_diningroomroomlevel = models.TextField(db_column='NST_DiningRoomRoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom1roomdescription = models.TextField(db_column='NST_ExtraRoom1RoomDescription', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom1roomdimensions = models.TextField(db_column='NST_ExtraRoom1RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom1roomlevel = models.TextField(db_column='NST_ExtraRoom1RoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom2roomdescription = models.TextField(db_column='NST_ExtraRoom2RoomDescription', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom2roomdimensions = models.TextField(db_column='NST_ExtraRoom2RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom2roomlevel = models.TextField(db_column='NST_ExtraRoom2RoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom3roomdescription = models.TextField(db_column='NST_ExtraRoom3RoomDescription', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom3roomdimensions = models.TextField(db_column='NST_ExtraRoom3RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom3roomlevel = models.TextField(db_column='NST_ExtraRoom3RoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom4roomdescription = models.TextField(db_column='NST_ExtraRoom4RoomDescription', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom4roomdimensions = models.TextField(db_column='NST_ExtraRoom4RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom4roomlevel = models.TextField(db_column='NST_ExtraRoom4RoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom5roomdescription = models.TextField(db_column='NST_ExtraRoom5RoomDescription', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom5roomdimensions = models.TextField(db_column='NST_ExtraRoom5RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom5roomlevel = models.TextField(db_column='NST_ExtraRoom5RoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom6roomdescription = models.TextField(db_column='NST_ExtraRoom6RoomDescription', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom6roomdimensions = models.TextField(db_column='NST_ExtraRoom6RoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_extraroom6roomlevel = models.TextField(db_column='NST_ExtraRoom6RoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_familyroomroomdimensions = models.TextField(db_column='NST_FamilyRoomRoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_familyroomroomfeatures = models.TextField(db_column='NST_FamilyRoomRoomFeatures', blank=True, null=True)  # Field name made lowercase.
    nst_familyroomroomlevel = models.TextField(db_column='NST_FamilyRoomRoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_kitchenroomdimensions = models.TextField(db_column='NST_KitchenRoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_kitchenroomlevel = models.TextField(db_column='NST_KitchenRoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_leaseexpirationdt = models.TextField(db_column='NST_LeaseExpirationDt', blank=True, null=True)  # Field name made lowercase.
    nst_livingroomroomdimensions = models.TextField(db_column='NST_LivingRoomRoomDimensions', blank=True, null=True)  # Field name made lowercase.
    nst_livingroomroomlevel = models.TextField(db_column='NST_LivingRoomRoomLevel', blank=True, null=True)  # Field name made lowercase.
    nst_monthlyexpenses = models.TextField(db_column='NST_MonthlyExpenses', blank=True, null=True)  # Field name made lowercase.
    nst_unitamenities = models.TextField(db_column='NST_UnitAmenities', blank=True, null=True)  # Field name made lowercase.
    nst_unitappl = models.TextField(db_column='NST_UnitAppl', blank=True, null=True)  # Field name made lowercase.
    nst_unitbath3qtr = models.TextField(db_column='NST_UnitBath3Qtr', blank=True, null=True)  # Field name made lowercase.
    nst_unitbathfull = models.TextField(db_column='NST_UnitBathFull', blank=True, null=True)  # Field name made lowercase.
    nst_unitbathhalf = models.TextField(db_column='NST_UnitBathHalf', blank=True, null=True)  # Field name made lowercase.
    nst_unitbathqtr = models.TextField(db_column='NST_UnitBathQtr', blank=True, null=True)  # Field name made lowercase.
    nst_unitcoolsystem = models.TextField(db_column='NST_UnitCoolSystem', blank=True, null=True)  # Field name made lowercase.
    nst_unitfireplacelocation = models.TextField(db_column='NST_UnitFireplaceLocation', blank=True, null=True)  # Field name made lowercase.
    nst_unitfireplacenum = models.TextField(db_column='NST_UnitFireplaceNum', blank=True, null=True)  # Field name made lowercase.
    nst_unitfurnished = models.TextField(db_column='NST_UnitFurnished', blank=True, null=True)  # Field name made lowercase.
    nst_unitid = models.TextField(db_column='NST_UnitID', blank=True, null=True)  # Field name made lowercase.
    nst_unitisleased = models.TextField(db_column='NST_UnitIsLeased', blank=True, null=True)  # Field name made lowercase.
    nst_unitleaseterm = models.TextField(db_column='NST_UnitLeaseTerm', blank=True, null=True)  # Field name made lowercase.
    nst_unitlevel = models.TextField(db_column='NST_UnitLevel', blank=True, null=True)  # Field name made lowercase.
    nst_unitnumber = models.TextField(db_column='NST_UnitNumber', blank=True, null=True)  # Field name made lowercase.
    nst_unitparking = models.TextField(db_column='NST_UnitParking', blank=True, null=True)  # Field name made lowercase.
    nst_unitroomspec = models.TextField(db_column='NST_UnitRoomSpec', blank=True, null=True)  # Field name made lowercase.
    nst_unitroomstotal = models.TextField(db_column='NST_UnitRoomsTotal', blank=True, null=True)  # Field name made lowercase.
    nst_unitsqft = models.TextField(db_column='NST_UnitSqFt', blank=True, null=True)  # Field name made lowercase.
    unittypeactualrent = models.DecimalField(db_column='UnitTypeActualRent', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    unittypebathstotal = models.SmallIntegerField(db_column='UnitTypeBathsTotal', blank=True, null=True)  # Field name made lowercase.
    unittypebedstotal = models.SmallIntegerField(db_column='UnitTypeBedsTotal', blank=True, null=True)  # Field name made lowercase.
    unittypekey = models.TextField(db_column='UnitTypeKey', primary_key=True)  # Field name made lowercase.
    unittypetotalrent = models.DecimalField(db_column='UnitTypeTotalRent', max_digits=18, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    unittypeunitstotal = models.SmallIntegerField(db_column='UnitTypeUnitsTotal', blank=True, null=True)  # Field name made lowercase.
    listingid = models.TextField(db_column='ListingId', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'propertyunittypes'


class YourTableName(models.Model):
    your_column_name = models.IntegerField(primary_key=True)
    tmp_bill = models.TextField(blank=True, null=True)
    sixwork = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'your_table_name'
