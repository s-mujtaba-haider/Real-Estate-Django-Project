from django.urls import path
from .views import BasePage,MlsPage,MlsData,MlsSpecificPage,MlsSpecificData,GetIndexingSpecific,GetIndexingAll,GetPropertyData,UpdateTable,GetPropertyAddr
from .views import GetLogs,LogSystem,LogTable,LoginPage,AddUser,ChatPage

urlpatterns = [
    path('',LoginPage,name='login_page'),
    path('main/',BasePage,name="base_page"),
    path('chat/',ChatPage,name='chat_app'),
    # path('',BasePage,name="base_page"),
    path('add/user',AddUser,name="add_user"),
    path('view/mls',MlsPage,name="mls_page"),
    path('view/mls/data',MlsData,name="table_data"),
    path('view/mls-specific/',MlsSpecificPage,name="mls_page_specific"),
    path('view/mls-specific/data',MlsSpecificData,name="table_data_specific"),
    path('data/specific/',GetIndexingSpecific.as_view(),name='view_data'),
    path('data/all/',GetIndexingAll.as_view(),name='view_data_all'),
    path('data/property/<str:property_id>',GetPropertyData.as_view(),name='property_data'),
    path('data/address/property',GetPropertyAddr.as_view(),name='property_data_addr'),
    path('match/tables/',UpdateTable.as_view(),name='update-table'),
    path('view/logs/',LogSystem,name='logs_option'),
    path('view/mls-specific/logs',LogTable,name="table_logs"),
    path('get/logs/',GetLogs.as_view(),name='get-logs')
]
