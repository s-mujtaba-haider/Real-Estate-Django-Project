CREATE INDEX idx_ListingId ON Property(ListingId(255));
CREATE INDEX idx_BuyerOfficeKey ON property(BuyerOfficeKey);
CREATE INDEX idx_BuyerAgentKey ON property(BuyerAgentKey(255));
CREATE INDEX idx_ListAgentKey ON Property(ListAgentKey(255));
CREATE INDEX idx_ListingIdMedia ON Media(ListingId(255));
CREATE INDEX idx_ListingIdUnit ON PropertyUnitTypes(ListingId(255));
CREATE INDEX idx_ListingIdRooms ON PropertyRooms(ListingId(255));
CREATE INDEX idx_OfficeKey ON Office(OfficeKey(255));
CREATE INDEX idx_MemberKey ON Member(MemberKey(255));

OfficeKey
ALTER TABLE Media
ADD COLUMN ListingId TEXT;

ALTER TABLE PropertyRooms
ADD COLUMN ListingId TEXT;

ALTER TABLE PropertyUnitTypes
ADD COLUMN ListingId TEXT;


class GetPropertyData(APIView):

    def get(self,request,property_id):

        with connections['second_db'].cursor() as cursor_default:
            cursor_default.execute(f"""
            SELECT *
            FROM property
            LEFT JOIN office ON property.BuyerOfficeKey = office.OfficeKey
            LEFT JOIN member AS BuyerAgentMember ON property.BuyerAgentKey = BuyerAgentMember.MemberKey
            LEFT JOIN member AS ListAgentMember ON property.ListAgentKey = ListAgentMember.MemberKey
            LEFT JOIN media ON property.ListingId = media.ListingId
            LEFT JOIN propertyunittypes ON property.ListingId = propertyunittypes.ListingId
            LEFT JOIN propertyrooms ON property.ListingId = propertyrooms.ListingId
            WHERE property.ListingId = '{property_id}';
            """)
            default_data = cursor_default.fetchall()
        

        with connections['second_db'].cursor() as cursor_default:
            cursor_default.execute(f"""
            SELECT *
            FROM media
            WHERE media.ListingId = '{property_id}';
            """)
            media_data = cursor_default.fetchall()
        
        with connections['second_db'].cursor() as cursor_default:
            cursor_default.execute(f"""
            SELECT *
            FROM propertyunittypes
            WHERE propertyunittypes.ListingId = '{property_id}';
            """)
            unit_data = cursor_default.fetchall()
        
        with connections['second_db'].cursor() as cursor_default:
            cursor_default.execute(f"""
            SELECT *
            FROM propertyrooms
            WHERE propertyrooms.ListingId = '{property_id}';
            """)
            rooms_data = cursor_default.fetchall()
        
        
        
        try:
            with connections['second_db'].cursor() as cursor_columns:
                cursor_columns.execute(f"SHOW COLUMNS FROM property")
                property_columns = [column[0] for column in cursor_columns.fetchall()]
        except ProgrammingError as e:
            # Handle the error when executing the SHOW COLUMNS query
            print(f"Error executing SHOW COLUMNS query for default database: {e}")
            property_columns = []
        
        
        my_column=[]
        try:
            with connections['second_db'].cursor() as cursor_columns:
                cursor_columns.execute(f"SHOW COLUMNS FROM office")
                office_columns=[column[0] for column in cursor_columns.fetchall()]
        except ProgrammingError as e:
            # Handle the error when executing the SHOW COLUMNS query
            print(f"Error executing SHOW COLUMNS query for default database: {e}")
            office_column=[]
             
        try:
            with connections['second_db'].cursor() as cursor_columns:
                cursor_columns.execute(f"SHOW COLUMNS FROM member")
                member_columns=[column[0] for column in cursor_columns.fetchall()]
        except ProgrammingError as e:
            member_columns=[]
        
        try:
            with connections['second_db'].cursor() as cursor_columns:
                cursor_columns.execute(f"SHOW COLUMNS FROM media")
                media_columns=[column[0] for column in cursor_columns.fetchall()]
        except ProgrammingError as e:
            media_columns=[]
        
        try:
            with connections['second_db'].cursor() as cursor_columns:
                cursor_columns.execute(f"SHOW COLUMNS FROM propertyunittypes")
                unit_columns=[column[0] for column in cursor_columns.fetchall()]
        except ProgrammingError as e:
            unit_columns=[]
        

        try:
            with connections['second_db'].cursor() as cursor_columns:
                cursor_columns.execute(f"SHOW COLUMNS FROM propertyrooms")
                room_columns=[column[0] for column in cursor_columns.fetchall()]
        except ProgrammingError as e:
            room_columns=[]
        

        columns= property_columns + office_columns + member_columns + member_columns + media_columns + unit_columns + room_columns
        json_response_default = []
        for row in default_data:
            row_dict = {}
            for idx, column_name in enumerate(columns):
                row_dict[column_name] = row[idx] if idx < len(row) else None
            json_response_default.append(row_dict)
        
        row_dict={'media':media_data,'rooms':rooms_data,'unittypes':unit_data}
        json_response_default.append(row_dict)
        
        return Response(json_response_default)