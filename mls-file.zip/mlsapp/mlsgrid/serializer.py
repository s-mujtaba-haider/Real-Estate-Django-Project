from rest_framework import serializers
from .models import Logrecords

class LogSerializer(serializers.ModelSerializer):
    class Meta:
        model=Logrecords
        fields='__all__'

def create_dynamic_serializer(model_class):
    class DynamicModelSerializer(serializers.ModelSerializer):
        class Meta:
            model = model_class
            fields = '__all__'

    return DynamicModelSerializer
