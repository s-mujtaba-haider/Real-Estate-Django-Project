from django.shortcuts import render
from django.db import connections, ProgrammingError
from django.core.paginator import Paginator
from django.forms.models import model_to_dict
from django.db.models import Q,F,Value,Case, When, CharField
from django.http import JsonResponse
from django.apps import apps
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import redirect
from django.urls import reverse
from decimal import Decimal
from datetime import datetime, timedelta, date
from .serializer import LogSerializer,create_dynamic_serializer
from .models import Logrecords,Media,Property,Office,Member,Propertyrooms,Propertyunittypes
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.db.models.functions import Concat, Replace
from django.db import models
from scourgify import normalize_address_record, NormalizeAddress
import json
import re
import os


def LoginPage(request):
    return render(request,'login.html')

def ChatPage(request):
    return render(request,'chat.html')

def BasePage(request):
    if not request.user.is_authenticated:
        return redirect(reverse('login_page'))
    return render(request, 'main.html')

def AddUser(request):
    if not request.user.is_authenticated:
        return redirect(reverse('login_page'))
    return render(request,'register.html')

def MlsPage(request):
    if not request.user.is_authenticated:
        return redirect(reverse('login_page'))
    return render(request, 'mlsall.html')

def MlsSpecificPage(request):
    if not request.user.is_authenticated:
        return redirect(reverse('login_page'))
    return render(request, 'mlsspecific.html')

def MlsSpecificData(request):
    if not request.user.is_authenticated:
        return redirect(reverse('login_page'))
    return render(request,'mlsspecifictable.html')

def LogSystem(request):
    if not request.user.is_authenticated:
        return redirect(reverse('login_page'))
    return render(request,'logs/main.html')

def LogTable(request):
    if not request.user.is_authenticated:
        return redirect(reverse('login_page'))
    return render(request,'api-logs/logtable.html')

@method_decorator(csrf_exempt, name='dispatch')
class GetIndexingSpecific(APIView):

    def post(self,request):
        
        # data = json.loads(request.body.decode('utf-8'))
        category = request.data.get('category')
        subcategory = request.data.get('selectedCategory')
        start = int(request.data.get('start', 0))
        length = int(request.data.get('length', 10)) 
        search_value = request.data.get('search_value', '')
        start_date = request.data.get('start_date')
        end_date = request.data.get('end_date')
     
    #     category = data.get('category')
    #     subcategory = data.get('selectedCategory')
    #     start = int(data.get('start', 0))
    #     length = int(data.get('length', 10)) 
    #     search_value = data.get('search_value', '')
    #     start_date = data.get('start_date')
    #     end_date = data.get('end_date')
    #     log_file_relative_path=''

        if subcategory=='northstar2':
            subcategory='default'
            applabel='mlsgrid'
            log_file_relative_path = 'logs/northstar.log'
        else:
            subcategory='second_db'
            applabel='stellarapp'
            log_file_relative_path = 'logs/stellar.log'
        
        
        if category=='Logrecords':

            log_entries=self.get_logs_data(log_file_relative_path)

            if (request.data.get('header_param')=='true'):
                queryset = log_entries[:1]
            else:
                queryset = log_entries[:1000]
        
            if search_value:
                keys = log_entries[0].keys()
                field_names = list(keys)
                
                queryset = [
                    item for item in log_entries if any(
                        str(search_value).lower() in str(item.get(field, '')).lower() 
                        for field in field_names
                    )
                ]
            else:
                queryset = log_entries
                
            if start_date and end_date:
                startdate = datetime.strptime(start_date, "%Y-%m-%d").date()
                enddate = datetime.strptime(end_date, "%Y-%m-%d").date()
                if enddate > startdate:
                    queryset = [item for item in log_entries if startdate <= item['timestamp'].date() <= enddate]  
                else:
                    queryset=[]
        
            paginated_data=self.custom_pagination(queryset,start,length)
            
            return JsonResponse({
            'data': paginated_data,
            'recordsTotal': len(queryset),
            'recordsFiltered': len(queryset),
        })

        else:
            
            serializer_class = self.get_serializer_class(category,applabel)

            if serializer_class is None:
                return JsonResponse({'error': f'Invalid model name: {category}'}, status=400)
            
            if (request.data.get('header_param')=='true'):
                queryset = serializer_class.Meta.model.objects.using(subcategory).all()[:1]
            else:
                # if serializer_class.Meta.model=='logrecords':
                #     queryset = serializer_class.Meta.model.objects.using(subcategory).all().order_by('-created_at')[:100000] # get latest logs
                # else:
                queryset = serializer_class.Meta.model.objects.using(subcategory).all()[:100000]
            
            # if search_value and category=='Logrecords':
            #     model=serializer_class.Meta.model
            #     field_names=[field.name for field in model._meta.get_fields()]
            #     filter_params=Q()

            #     for field in field_names:
            #         filter_params |= Q(**{f'{field}__icontains': search_value})

            #     queryset = model.objects.using(subcategory).filter(filter_params)

            if search_value:
                model=serializer_class.Meta.model
                field_names=[field.name for field in model._meta.get_fields()]
                filter_params=Q()

                for field in field_names:
                    filter_params |= Q(**{f'{field}__icontains': search_value})

                queryset = model.objects.using(subcategory).filter(filter_params)
            

            
            if start_date and end_date:
                startdate = datetime.strptime(start_date, "%Y-%m-%d").date()
                enddate = datetime.strptime(end_date, "%Y-%m-%d").date()

                if enddate > startdate:
                    try:
                            if category=='Media':
                                queryset = serializer_class.Meta.model.objects.using(subcategory).filter(mediamodificationtimestamp__date__range=(startdate, enddate))               
                            # elif category=='Logrecords':
                            #     queryset = serializer_class.Meta.model.objects.using(subcategory).filter(created_at__date__range=(startdate, enddate))
                            else:
                                queryset = serializer_class.Meta.model.objects.using(subcategory).filter(modificationtimestamp__date__range=(startdate, enddate))
                    except Exception as e:
                            queryset=[]
                else:
                        return JsonResponse({"error": "End Date should be bigger than Start Date"})
            
            
            paginator = Paginator(queryset, length)
            page = paginator.get_page(start // length + 1)  # Calculate the page number
            
            
            serializer = serializer_class(page.object_list, many=True)
            serialized_data = serializer.data
            
            return JsonResponse({
            'data': serialized_data,
            'recordsTotal': paginator.count,
            'recordsFiltered': paginator.count,
        })
        
    
    def get_serializer_class(self, model_name,app_name):
        try:
            # Get the model class dynamically using apps.get_model
            model_class = apps.get_model(app_label=app_name, model_name=model_name)
            return create_dynamic_serializer(model_class)
        except ValueError:
            return None
    
    def custom_pagination(self,queryset,start,length):
        end = start + length
        paginated_data = queryset[start:end]
        return paginated_data
        
    
    def get_logs_data(self,log_file_relative_path):

        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        log_file_path = os.path.join(BASE_DIR, log_file_relative_path)
        log_entries = []

        with open(log_file_path, 'r') as file:
            for line in file:
                parts = line.strip().split(' - ')
                if len(parts) == 3:
                    timestamp_str, level, message = parts
                    timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                    log_entries.append({
                        'timestamp': timestamp,
                        'level': level.strip(),
                        'message': message.strip()
                    })
            else:
                pass
        
        return log_entries
        
    
def MlsData(request):
    if not request.user.is_authenticated:
        return redirect(reverse('user_login'))
    return render(request, 'mlssalltable.html')

# @method_decorator(csrf_exempt, name='dispatch')
class GetIndexingAll(APIView):

    def post(self,request):
        # data = json.loads(request.body.decode('utf-8'))
        # category = data.get('category')
        # start = int(data.get('start', 0))
        # length = int(data.get('length', 10)) 
        # search_value = data.get('search_value', '')
        # start_date = data.get('start_date')
        # end_date = data.get('end_date')

        category = request.data.get('category')
        subcategory = request.data.get('selectedCategory')
        start = int(request.data.get('start', 0))
        length = int(request.data.get('length', 10)) 
        search_value = request.data.get('search_value', '')
        start_date = request.data.get('start_date')
        end_date = request.data.get('end_date')

        applabel='mlsgrid'
        serializer_class = self.get_serializer_class(category,applabel)
        
        applabel='stellarapp'
        serializer_class_second = self.get_serializer_class(category,applabel)

        if serializer_class is None:
            return JsonResponse({'error': f'Invalid model name: {category}'}, status=400)
        
        if serializer_class_second is None:
            return JsonResponse({'error': f'Invalid model name: {category}'}, status=400)
        
        if (request.data.get('header_param')=='true'):
            queryset_default = serializer_class.Meta.model.objects.using('default').all()[:1]
            queryset_second_db = serializer_class_second.Meta.model.objects.using('second_db').all()[:1]
        else:
            queryset_default = serializer_class.Meta.model.objects.using('default').all()[:100000]
            queryset_second_db = serializer_class_second.Meta.model.objects.using('second_db').all()[:100000]
        
        queryset = list(queryset_default) + list(queryset_second_db)
        
        if search_value and category=='Logrecords':

            model=serializer_class.Meta.model
            field_names=[field.name for field in model._meta.get_fields()]
            filter_params=Q()

            for field in field_names:
                filter_params |= Q(**{f'{field}__icontains': search_value})

            queryset = model.objects.using('default').filter(filter_params)

            if not queryset:

                 model=serializer_class_second.Meta.model
                 field_names=[field.name for field in model._meta.get_fields()]
                 filter_params=Q()

                 for field in field_names:
                    filter_params |= Q(**{f'{field}__icontains': search_value})

                 queryset = model.objects.using('second_db').filter(filter_params)


        elif search_value:

            model=serializer_class.Meta.model
            field_names=[field.name for field in model._meta.get_fields()]
            filter_params=Q()

            for field in field_names:
                filter_params |= Q(**{f'{field}__icontains': search_value})

            queryset = model.objects.using('default').filter(filter_params)

            if not queryset:

                 model=serializer_class_second.Meta.model
                 field_names=[field.name for field in model._meta.get_fields()]
                 filter_params=Q()

                 for field in field_names:
                    filter_params |= Q(**{f'{field}__icontains': search_value})

                 queryset = model.objects.using('second_db').filter(filter_params)
           

        
        if start_date and end_date:
           startdate = datetime.strptime(start_date, "%Y-%m-%d").date()
           enddate = datetime.strptime(end_date, "%Y-%m-%d").date()

           if enddate > startdate:
               try:
                    if category=='Media':
                        queryset = serializer_class.Meta.model.objects.using('default').filter(mediamodificationtimestamp__date__range=(startdate, enddate))               
                    elif category=='Logrecords':
                        queryset = serializer_class.Meta.model.objects.using('default').filter(created_at__date__range=(startdate, enddate))
                    else:
                        queryset = serializer_class.Meta.model.objects.using('default').filter(modificationtimestamp__date__range=(startdate, enddate))
               except Exception as e:
                    try:
                            if category=='Media':
                                queryset = serializer_class.Meta.model.objects.using('second_db').filter(mediamodificationtimestamp__date__range=(startdate, enddate))               
                            elif category=='Logrecords':
                                queryset = serializer_class.Meta.model.objects.using('second_db').filter(created_at__date__range=(startdate, enddate))
                            else:
                                queryset = serializer_class.Meta.model.objects.using('second_db').filter(modificationtimestamp__date__range=(startdate, enddate))
                    except Exception as e:
                            queryset=[]
           else:
                 return JsonResponse({"error": "End Date should be bigger than Start Date"})
           
        
        paginator = Paginator(queryset, length)
        page = paginator.get_page(start // length + 1)  # Calculate the page number
        
        
        serializer = serializer_class(page.object_list, many=True)
        serialized_data = serializer.data
        
        return JsonResponse({
        'data': serialized_data,
        'recordsTotal': paginator.count,
        'recordsFiltered': paginator.count,
    })

    def get_serializer_class(self, model_name,app_name):
        try:
            # Get the model class dynamically using apps.get_model
            model_class = apps.get_model(app_label=app_name, model_name=model_name)
            return create_dynamic_serializer(model_class)
        except ValueError:
            return None

class GetPropertyData(APIView):

    def get(self,request,property_id):

        escaped_property_id = re.escape(property_id)
        property_info,select_app=self.getProperty(escaped_property_id)
         
        if property_info:

            if select_app=='stellarapp':
                select_db='second_db'
            else:
                select_db='default'

            try :
                serializer_class = self.get_serializer_class('Office',select_app)
                office = serializer_class.Meta.model.objects.using(select_db).get(officekey=property_info.buyerofficekey)
            except serializer_class.Meta.model.DoesNotExist:
                office=[]
            
            try :
                serializer_class = self.get_serializer_class('Member',select_app)      
                member_buyeragent = serializer_class.Meta.model.objects.using(select_db).get(memberkey=property_info.buyeragentkey)
            except serializer_class.Meta.model.DoesNotExist:
                member_buyeragent=[]
            
            try:
                serializer_class = self.get_serializer_class('Member',select_app)
                member_listagent = serializer_class.Meta.model.objects.using(select_db).get(memberkey=property_info.listagentkey)
            except serializer_class.Meta.model.DoesNotExist:
                member_listagent=[]

            serializer_class = self.get_serializer_class('Media',select_app)
            media = serializer_class.Meta.model.objects.using(select_db).filter(listingid__regex=r'^\D*{}$'.format(escaped_property_id))
            serializer_class = self.get_serializer_class('Propertyrooms',select_app)
            rooms = serializer_class.Meta.model.objects.using(select_db).filter(listingid__regex=r'^\D*{}$'.format(escaped_property_id))
            serializer_class = self.get_serializer_class('Propertyunittypes',select_app)
            units = serializer_class.Meta.model.objects.using(select_db).filter(listingid__regex=r'^\D*{}$'.format(escaped_property_id))
            

            res_data = {}
            property_dict = model_to_dict(property_info)

            if office:
                office_dict = model_to_dict(office)
            else:
                office_dict=[]
            
            if member_buyeragent:
                memberbuyer_dict = model_to_dict(member_buyeragent)
            else:
                memberbuyer_dict = []
            
            if member_listagent:
                memberlist_dict = model_to_dict(member_listagent)
            else:
                memberlist_dict=[]

            res_data['property'] = property_dict
            res_data['media'] = media.values()
            res_data['rooms'] = rooms.values()
            res_data['units'] = units.values()
            res_data['office'] = office_dict
            res_data['member_buyer'] = memberbuyer_dict
            res_data['member_agent'] = memberlist_dict

            return Response(res_data)
        else:
            return Response([])

    def getProperty(self,id):

            try:
                serializer_class = self.get_serializer_class('Property','mlsgrid')
                property_info=serializer_class.Meta.model.objects.using('default').get(listingid__regex=r'^\D*{}$'.format(id))
                return property_info,'mlsgrid'
            except Property.DoesNotExist:
                try:
                    serializer_class = self.get_serializer_class('Property','stellarapp')
                    property_info=serializer_class.Meta.model.objects.using('second_db').get(listingid__regex=r'^\D*{}$'.format(id))
                    return property_info,'stellarapp'
                except Property.DoesNotExist:
                    return None,None
    
    def get_serializer_class(self, model_name,app_name):
        try:
            # Get the model class dynamically using apps.get_model
            model_class = apps.get_model(app_label=app_name, model_name=model_name)
            return create_dynamic_serializer(model_class)
        except ValueError:
            return None


class CustomEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, (datetime, date)):
            return obj.isoformat()
        return super(CustomEncoder, self).default(obj)

class GetPropertyAddr(APIView):

    def post(self,request):
        
        address = request.data.get('address')
        naddr=NormalizeAddress(address,long_hand=True).normalize()
        addr=''
        for key,value in naddr.items():
            if value is not None:
                if key=='address_line_1':
                    value=self.replace_directions(value)
                addr=addr+value+' '
        addr = addr.replace(',', '')
        print(addr)
        property_data,select_app=self.getdbaddr(addr)
        total_property_items={}
        print('property_data',property_data)
        if property_data is not None:

            if select_app == 'stellarapp':
                select_db='second_db'
            else:
                select_db='default'
            
            property_data_list=[]
            
            for property_info in property_data:
                # try :
                #     serializer_class = self.get_serializer_class('Office',select_app)
                #     office = serializer_class.Meta.model.objects.using(select_db).get(officekey=property_info.buyerofficekey)
                # except serializer_class.Meta.model.DoesNotExist:
                #     office=[]
                
                # try :
                #     serializer_class = self.get_serializer_class('Member',select_app)      
                #     member_buyeragent = serializer_class.Meta.model.objects.using(select_db).get(memberkey=property_info.buyeragentkey)
                # except serializer_class.Meta.model.DoesNotExist:
                #     member_buyeragent=[]
                
                # try:
                #     serializer_class = self.get_serializer_class('Member',select_app)
                #     member_listagent = serializer_class.Meta.model.objects.using(select_db).get(memberkey=property_info.listagentkey)
                # except serializer_class.Meta.model.DoesNotExist:
                #     member_listagent=[]

                # serializer_class = self.get_serializer_class('Media',select_app)
                # media = serializer_class.Meta.model.objects.using(select_db).filter(listingid=property_info.listingid)                
                serializer_class = self.get_serializer_class('Propertyrooms',select_app)
                rooms = serializer_class.Meta.model.objects.using(select_db).filter(listingid=property_info.listingid)
                # serializer_class = self.get_serializer_class('Propertyunittypes',select_app)
                # units = serializer_class.Meta.model.objects.using(select_db).filter(listingid=property_info.listingid)
                
                # media_data=[]
                # for mediaitems in media.values():
                #     media_dict_filtered = {key: value for key, value in mediaitems.items() if value is not None}
                #     media_data.append(media_dict_filtered)
                
                room_data=[]
                for roomitems in rooms.values():
                    room_dict_filtered = {key: value for key, value in roomitems.items() if value is not None}
                    room_data.append(room_dict_filtered)

                # unit_data=[]
                # for unititems in units.values():
                #     unit_dict_filtered = {key: value for key, value in unititems.items() if value is not None}
                #     unit_data.append(unit_dict_filtered)


                property_dict = model_to_dict(property_info)
                property_dict_filtered = {key: value for key, value in property_dict.items() if value is not None and value != 0 and value != 0.0}

                # if office:
                #     office_dict = model_to_dict(office)
                #     office_dict_filtered = {key: value for key, value in office_dict.items() if value is not None}
                #     property_dict_filtered['office']=office_dict_filtered
                # else:
                #     office_dict=[]
                
                # if member_buyeragent:
                #     memberbuyer_dict = model_to_dict(member_buyeragent)
                #     memberbuyer_dict_filtered = {key: value for key, value in memberbuyer_dict.items() if value is not None}
                #     property_dict_filtered['memberbuyer']=memberbuyer_dict_filtered
                # else:
                #     memberbuyer_dict = []
                
                # if member_listagent:
                #     memberlist_dict = model_to_dict(member_listagent)
                #     memberlist_dict_filtered = {key: value for key, value in memberlist_dict.items() if value is not None}
                #     property_dict_filtered['memberlist']=memberlist_dict_filtered
                # else:
                #     memberlist_dict=[]
         
                # property_dict_filtered['media']=media_data
                property_dict_filtered['room']=room_data
                # property_dict_filtered['unit']=unit_data
               
                property_data_list.append(property_dict_filtered)
                
               
            total_property_items={'properties':property_data_list}
            json_data = json.dumps(total_property_items, cls=CustomEncoder, indent=4)

            with open('data-api.txt','w') as file:
                file.write(str(json_data))

            print("API work done!")
            return Response(total_property_items)
        else:
            return Response()

    def getdbaddr(self,address):
            serializer_class = self.get_serializer_class('Property','mlsgrid')
            properties_with_concatenated_fields = serializer_class.Meta.model.objects.using('default').annotate(
                concatenated_fields=Concat(
                    F('streetnumber'), Value(' '), 
                    F('streetname'), Value(' '), 
                    F('streetsuffix'), Value(' '),
                    F('postalcity'), Value(' '),
                    F('stateorprovince'), Value(' '),
                    F('postalcode'),
                    output_field=models.CharField()  # Specify the output field type
                    )
            )

            words_to_match = address.split()
            combined_query = Q()

            for word in words_to_match:
                combined_query &= Q(concatenated_fields__icontains=word)

            try:
                property_info = properties_with_concatenated_fields.using('default').filter(combined_query)
                return property_info,'mlsgrid'
            except serializer_class.Meta.model.DoesNotExist:
                serializer_class = self.get_serializer_class('Property','stellarapp')
                properties_with_concatenated_fields = serializer_class.Meta.model.objects.using('second_db').annotate(
                concatenated_fields=Concat(
                    F('streetnumber'), Value(' '), 
                    F('streetname'), Value(' '), 
                    F('streetsuffix'), Value(' '),
                    F('city'), Value(' '),
                    F('stateorprovince'), Value(' '),
                    F('postalcode'),
                    output_field=models.CharField()
                    
                    )
                )

                words_to_match = address.split()
                combined_query = Q()

                for word in words_to_match:
                    combined_query &= Q(concatenated_fields__icontains=word)

                try:
                    property_info = properties_with_concatenated_fields.using('second_db').filter(combined_query)
                    return property_info,'stellarapp'
                except serializer_class.Meta.model.DoesNotExist:
                    return None,None
    
    def get_serializer_class(self, model_name,app_name):
        try:
            # Get the model class dynamically using apps.get_model
            model_class = apps.get_model(app_label=app_name, model_name=model_name)
            return create_dynamic_serializer(model_class)
        except ValueError:
            return None
    
    def replace_directions(self,text):
        replacements = {"SOUTH": "S", "NORTH": "N", "EAST": "E", "WEST": "W"}
        for direction, abbreviation in replacements.items():
            text = text.replace(direction, abbreviation)
        return text
        
class UpdateTable(APIView):

    def get(self,request):

        inspectdb_command = "python manage.py inspectdb > mlsgrid/models.py"
        os.system(inspectdb_command)
        os.system('python manage.py makemigrations mlsgrid')
        os.system('python manage.py migrate')

        return Response ('Model Generated')


class GetLogs(APIView):

    def post(self,request):
        #data = json.loads(request.body.decode('utf-8'))
        subcategory = request.data.get('categoryLogs')
        start = int(request.data.get('start', 0))
        length = int(request.data.get('length', 10)) 
        search_value = request.data.get('search_value', '')
        start_date = request.data.get('start_date')
        end_date = request.data.get('end_date')

        if subcategory=='northstar2':
            log_file_relative_path = 'logs/northstar-api-forward.log'
        elif subcategory=='stellar':
            log_file_relative_path = 'logs/stellar-api-forward.log'
        else:
            log_file_relative_path = 'none'
        
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        log_file_path = os.path.join(BASE_DIR, log_file_relative_path)
        log_entries = []

        with open(log_file_path, 'r') as file:
            for line in file:
                parts = line.strip().split(' - ')
                if len(parts) == 3:
                    timestamp_str, level, message = parts
                    timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                    log_entries.append({
                        'timestamp': timestamp,
                        'level': level.strip(),
                        'message': message.strip()
                    })
            else:
                pass
        
        if (request.data.get('header_param')=='true'):
            queryset = log_entries[:1]
        else:
            queryset = log_entries[:100000]
        
        if search_value:
            keys = log_entries[0].keys()
            field_names = list(keys)
            
            # Filter the list based on search_value
            queryset = [
                item for item in log_entries if any(
                    str(search_value).lower() in str(item.get(field, '')).lower() 
                    for field in field_names
                )
            ]
        else:
            queryset = log_entries
            
        if start_date and end_date:
            startdate = datetime.strptime(start_date, "%Y-%m-%d").date()
            enddate = datetime.strptime(end_date, "%Y-%m-%d").date()
            if enddate > startdate:
                queryset = [item for item in log_entries if startdate <= item['timestamp'].date() <= enddate]  
                print(queryset) 
            else:
                queryset=[]
        
        paginated_data=self.custom_pagination(queryset,start,length)
        # paginator = Paginator(queryset, length)
        # page = paginator.get_page(start // length + 1)  # Calculate the page number
        
        return JsonResponse({
        'data': paginated_data,
        'recordsTotal': len(queryset),
        'recordsFiltered': len(queryset),
    })
        
    

    def custom_pagination(self,queryset,start,length):
        end = start + length
        paginated_data = queryset[start:end]
        return paginated_data


    